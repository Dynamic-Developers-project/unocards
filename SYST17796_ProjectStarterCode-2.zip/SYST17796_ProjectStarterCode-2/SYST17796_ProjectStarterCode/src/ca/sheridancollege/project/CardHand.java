package ca.sheridancollege.project;

public class CardHand {

	public void addCards() {
		// TODO - implement CardHand.addCards
		throw new UnsupportedOperationException();
	}
}