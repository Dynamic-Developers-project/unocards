/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sheridancollege.project;

/**
 *
 * @author HP LAPTOP
 */
public class WildCard extends Card {
    
    public WildCard(WildCards wildCards)
    {
        this.wildCards = wildCards;
    }
    
    public enum WildCards{
        wild,wildDraw4
    };
    
    private WildCards wildCards;
    
    /**
     *
     * @return
     */
    @Override
    public String toString()
    {
        return getWildCards()+"";
    }
    
    public WildCards getWildCards()
    {
        return this.wildCards;
    }
}
