package ca.sheridancollege.project;

import java.util.ArrayList;

public class UnoCardDeck extends GroupOfCards {

    public UnoCardDeck(int givenSize) {
        super(givenSize);
    }

    /**
     * the size of the grouping
     *
     * @param givenSize
     */
    public ArrayList<Card> unoDeck = new ArrayList();

    public void GroupOfCards(int givenSize) {
        // TODO - implement UnoCardDeck.GroupOfCards
        int i = 0;
        while (i < 2) {
            for (UnoCard.Suits suits : UnoCard.Suits.values()) {

                {
                    for (UnoCard.Value value : UnoCard.Value.values()) {

                        unoDeck.add(new UnoCard(suits, value));
                        
                    }
                }
                
            }
            i++;
        }

        int j = 0;

        while (j < 4) {
            for (WildCard.WildCards wild : WildCard.WildCards.values()) {
                unoDeck.add(new WildCard(wild));
            }
            j++;
        }
        int k = 0;
        while (k < 2) {
            for (ActionCard.Suits suits : ActionCard.Suits.values()) {

                for (ActionCard.ActCards actCard : ActionCard.ActCards.values()) {
                    unoDeck.add(new ActionCard(suits, actCard));
                }
            }
            k++;
        }

        for (ZeroCard.Suits suits : ZeroCard.Suits.values()) {

            unoDeck.add(new ZeroCard(suits));
        }

    }

    /**
     * A method that will get the group of cards as an ArrayList
     *
     * @return the group of cards.
     */
    public ArrayList<Card> showCards() {

        return unoDeck;
    }

    public void shuffle() {
        // TODO - implement UnoCardDeck.shuffle
        throw new UnsupportedOperationException();
    }

}
