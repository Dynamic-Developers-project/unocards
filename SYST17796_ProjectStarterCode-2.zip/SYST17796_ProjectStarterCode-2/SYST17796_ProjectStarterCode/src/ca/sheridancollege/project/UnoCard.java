package ca.sheridancollege.project;

public class UnoCard extends Card {

    private Suits suit ;
    private Value value ;

    public UnoCard(Suits suits, Value value) {
        this.suit = suits;
        this.value = value;
    }

    @Override
    public String toString() {
       return getSuit()+", "+getValue();
    }

    public enum Suits {
        Red, Blue, Yellow, Green
    };


    public enum Value {
        ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE
    };

    public Value getValue() {
        return this.value;
    }

    public Suits getSuit() {
        return this.suit;
    }
}
