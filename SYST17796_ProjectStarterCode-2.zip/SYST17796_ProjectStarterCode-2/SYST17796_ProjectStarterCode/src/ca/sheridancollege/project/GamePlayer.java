package ca.sheridancollege.project;

public class GamePlayer extends Player {

    public GamePlayer(String name) {
        super(name);
    }

    @Override
    public void play() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

	/**
	 * A constructor that allows you to set the player's unique ID
	 * @param name the unique ID to assign to this player.
	 */
	public void Player(String name) {
		// TODO - implement GamePlayer.Player
		throw new UnsupportedOperationException();
	}
}