package ca.sheridancollege.project;

public interface Compareable {

	boolean compare();
}