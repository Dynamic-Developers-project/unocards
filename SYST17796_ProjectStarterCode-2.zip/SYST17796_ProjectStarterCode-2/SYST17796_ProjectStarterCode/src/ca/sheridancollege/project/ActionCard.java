/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sheridancollege.project;

/**
 *
 * @author HP LAPTOP
 */
public class ActionCard extends Card{
    
    
    public ActionCard(Suits suits, ActCards actCards)
    {
        this.suits = suits;
        this.actCards = actCards;
    }
    
    public enum Suits {
        Red, Blue, Yellow, Green
    };
    
    public enum ActCards{
        Draw2, Skip, Reverse
    };
    
    private Suits suits;
    private ActCards actCards;

    public Suits getSuits()
    {
        return suits;
    }
    
    public ActCards getActCards()
    {
        return actCards;
    }
    
    @Override
    public String toString() {
        return getActCards()+", "+getSuits();
    }
    
}
