/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sheridancollege.project;

/**
 *
 * @author HP LAPTOP
 */
public class ZeroCard extends Card  {
    
    private Suits suits;
    
    public ZeroCard(Suits suits)
    {
        this.suits = suits;
    }

    public enum Suits{
        Red, Blue, Yellow, Green
    };
    
    public String toString()
    {
        return "Zero , "+getSuit();
    }
    
    public Suits getSuit()
    {
        return suits;
    }
}
