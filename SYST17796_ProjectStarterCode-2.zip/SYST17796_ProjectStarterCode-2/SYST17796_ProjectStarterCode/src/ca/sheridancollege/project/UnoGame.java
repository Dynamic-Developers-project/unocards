package ca.sheridancollege.project;

public class UnoGame extends Game implements Compareable {

    public UnoGame(String givenName) {
        super(givenName);
    }

    @Override
    public void play() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void declareWinner() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

	/**
	 * the players of the game
	 * @param givenName
	 */
	public void Game(String givenName) {
		// TODO - implement UnoGame.Game
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param card1
	 * @param card2
	 */
	public boolean compare(UnoCard card1, UnoCard card2) {
		// TODO - implement UnoGame.compare
		throw new UnsupportedOperationException();
	}

    @Override
    public boolean compare() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}