/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sheridancollege.project;

import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author khushi
 */
public class UnoCardDeckTest {
    
    public UnoCardDeckTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }

    /**
     * Test of GroupOfCards method, of class UnoCardDeck.
     */
    @Test
    public void testGroupOfCards() {
        System.out.println("GroupOfCards");
        int givenSize = 0;
        UnoCardDeck instance = null;
        instance.GroupOfCards(givenSize);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showCards method, of class UnoCardDeck.
     */
    @Test
    public void testShowCards() {
        System.out.println("showCards");
        UnoCardDeck instance = null;
        ArrayList<Card> expResult = null;
        ArrayList<Card> result = instance.showCards();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of shuffle method, of class UnoCardDeck.
     */
    @Test
    public void testShuffle() {
        System.out.println("shuffle");
        UnoCardDeck instance = null;
        instance.shuffle();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
