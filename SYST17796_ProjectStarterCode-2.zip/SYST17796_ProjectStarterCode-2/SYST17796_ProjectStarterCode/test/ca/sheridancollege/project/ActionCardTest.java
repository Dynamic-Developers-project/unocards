/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sheridancollege.project;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author khushi
 */
public class ActionCardTest {
    
    public ActionCardTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }

    /**
     * Test of getSuits method, of class ActionCard.
     */
    @Test
    public void testGetSuits() {
        System.out.println("getSuits");
        ActionCard instance = null;
        ActionCard.Suits expResult = null;
        ActionCard.Suits result = instance.getSuits();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getActCards method, of class ActionCard.
     */
    @Test
    public void testGetActCards() {
        System.out.println("getActCards");
        ActionCard instance = null;
        ActionCard.ActCards expResult = null;
        ActionCard.ActCards result = instance.getActCards();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class ActionCard.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        ActionCard instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
