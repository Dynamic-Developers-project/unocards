/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sheridancollege.project;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author khushi
 */
public class CardHandTest {
    
    public CardHandTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }

    /**
     * Test of addCards method, of class CardHand.
     */
    @Test
    public void testAddCards() {
        System.out.println("addCards");
        CardHand instance = new CardHand();
        instance.addCards();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
