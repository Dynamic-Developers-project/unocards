/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sheridancollege.project;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author khushi
 */
public class ZeroCardTest {
    
    public ZeroCardTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }

    /**
     * Test of toString method, of class ZeroCard.
     */
    @Test
    public void testToStringGood() {
        System.out.println("toStrinGood");
        ZeroCard instance = null;
        String expResult = "Red";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    public void testToStringBoundry() {
        System.out.println("toStringBoundry");
        ZeroCard instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    public void testToStringBad() {
        System.out.println("toStringBad");
        ZeroCard instance = null;
        String expResult = "Black";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    /**
     * Test of getSuit method, of class ZeroCard.
     */
    @Test
    public void testGetSuit() {
        System.out.println("getSuit");
        ZeroCard instance = null;
        ZeroCard.Suits expResult = null;
        ZeroCard.Suits result = instance.getSuit();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
