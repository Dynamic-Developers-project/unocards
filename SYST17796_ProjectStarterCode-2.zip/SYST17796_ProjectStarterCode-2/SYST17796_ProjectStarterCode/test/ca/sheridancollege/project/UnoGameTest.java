/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sheridancollege.project;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author khushi
 */
public class UnoGameTest {
    
    public UnoGameTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }

    /**
     * Test of play method, of class UnoGame.
     */
    @Test
    public void testPlay() {
        System.out.println("play");
        UnoGame instance = null;
        instance.play();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of declareWinner method, of class UnoGame.
     */
    @Test
    public void testDeclareWinner() {
        System.out.println("declareWinner");
        UnoGame instance = null;
        instance.declareWinner();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Game method, of class UnoGame.
     */
    @Test
    public void testGame() {
        System.out.println("Game");
        String givenName = "";
        UnoGame instance = null;
        instance.Game(givenName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of compare method, of class UnoGame.
     */
    @Test
    public void testCompare_UnoCard_UnoCard() {
        System.out.println("compare");
        UnoCard card1 = null;
        UnoCard card2 = null;
        UnoGame instance = null;
        boolean expResult = false;
        boolean result = instance.compare(card1, card2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of compare method, of class UnoGame.
     */
    @Test
    public void testCompare_0args() {
        System.out.println("compare");
        UnoGame instance = null;
        boolean expResult = false;
        boolean result = instance.compare();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
